require "spec_helper"

describe "routes to movies with same directors" do
  it "routes /movies/:id/similar to movies#same_director" do
    { :get => "/movies/123/similar" }.should route_to( 
	  :controller => "movies", 
	  :action => "same_director", 
	  :id => "123" )
  end
end