# This will guess the User class
FactoryGirl.define do
  factory :movie do
    title "John"
  end
end