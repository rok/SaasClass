require "spec_helper"

describe "Movie" do
  it "has accessible movie.id parameter" do
    Movie.create!(:title => "Star Wars", :id => 1)
	  Movie.find_by_title("Star Wars").id.should eq(1)
  end
  
  it "Movie.all_ratings returns an array of ratings: [G PG PG-13 NC-17 R]" do
	  Movie.all_ratings.should == %w(G PG PG-13 NC-17 R)
  end
  
  it "returns similar movies via Movie.similar_movies(id) method" do
    Movie.create!(:director => "George Lucas", :id => 1, :title => "Star Wares")
	  Movie.create!(:director => "George Lucas", :id => 2, :title => "Indiana Jones")
	  Movie.create!(:director => "Steven Spilberg", :id => 3, :title => "AI")
    Movie.similar_movies(1).should == [Movie.find_by_id(1), Movie.find_by_id(2)]
  end
  
  it "returns link to similar movies page via movie.similar_movies_path(id) method if director is known" do
    m = Movie.create!(:director => "George Lucas", :id => 1, :title => "Star Wars")
	  m.similar_movies_path(1,"George Lucas").should == "/movies/1/similar"
  end
  
  it "returns link to home page via movie.similar_movies_path(id) method and a flash if director is not known" do
	  m = Movie.create!(:id => 2, :title => "Alien", :director => nil)
	  m.similar_movies_path(2,nil).should == "/movies/?similar=" << "2"
  end
end