require 'spec_helper'
FactoryGirl.find_definitions

describe MoviesController, "show method" do
  it "should show movie with a given id" do
    FactoryGirl.create(:movie)
    get :show, :id => 1
    assigns(:movie).id.should == 1
  end
end

describe MoviesController, "same_director method" do
  it "should return movies similar to movie with a given id if they share the director" do
    6.times do
      FactoryGirl.create(:movie)
      FactoryGirl.create(:movie, :director => "Johnny")
    end
    get :same_director, :id => Movie.find_by_director("Johnny").id
    assigns(:movies).size.should == 6
	  assigns(:movies).last.director.should eq("Johnny")
  end

  it "should flash 'Movie' has no director info when sending user to movies_path" do
    5.times do
      FactoryGirl.create(:movie, :director => "Luka")
      FactoryGirl.create(:movie, :director => "Johnny")
    end
    m = FactoryGirl.create(:movie)
    get :index, :similar => m.id.to_s
    flash[:notice].should eq "'#{m.title}' has no director info."
  end
end

describe MoviesController, "index method" do
  it "returns movies in database without rating" do
    5.times do 
      FactoryGirl.create(:movie)
      FactoryGirl.create(:movie, :director => "Johnny")
    end
    get :index
    assigns(:movies).size.should eq(0)
  end
  
  it "redirects if we select a new rating and displays movies with a newley selected ratings" do
    5.times do 
      FactoryGirl.create(:movie, :rating => "G")
      FactoryGirl.create(:movie, :rating => "PG")
      FactoryGirl.create(:movie, :director => "Johnny", :rating => "PG-13")
    end
    get :index, :ratings => { :PG => 1 }
    assigns(:selected_ratings).should == { "PG" => "1" }
    response.should be_redirect

    get :index, :ratings => { :PG => 1 }
    assigns(:selected_ratings).should == { "PG" => "1" }
    
    assigns(:movies).size.should eq(5)
    assigns(:movies).nil?.should be_false
  end
  
  it "orderes movies by title or release date" do
    FactoryGirl.create(:movie, :title => "A", :rating => "G", :release_date => Time.at(3))
    FactoryGirl.create(:movie, :title => "B", :rating => "G", :release_date => Time.at(1))
    FactoryGirl.create(:movie, :title => "C", :rating => "G", :release_date => Time.at(2))
   
    get :index, :ratings => { :G => 1 }, :sort => :title
    response.should be_redirect
    get :index, :ratings => { :G => 1 }, :sort => :title
    assigns(:selected_ratings).should == { "G" => "1" }
    
    get :index, :ratings => { :G => 1 }, :sort => :release_date
    response.should be_redirect
    get :index, :ratings => { :G => 1 }, :sort => :release_date
    assigns(:selected_ratings).should == { "G" => "1" }

#    assigns(:sort).should == "title"
#    assigns(:movies).should eq Movie.find(:all, :order => :title)
#    get :index, :ratings => { :G => 1 }, :sort => "title"
#    assigns(:movies).should eq( Movie.find(:all, :order => :title) )
  end
end

describe MoviesController, "new method" do
  it "should work" do
    response.should be_success
  end
end

describe MoviesController, "destroy method" do
  it "should delete a movie" do
    m = FactoryGirl.create(:movie)
    n = FactoryGirl.create(:movie)
    put :destroy, :id => m.id
    assigns(:movie).should == m
    response.should redirect_to(movies_path)
  end
end

describe MoviesController, "create method" do
  it "should create a movie" do
    m = FactoryGirl.create(:movie)
    post :create, :title => m.title
    response.should redirect_to movies_path
    Movie.find_by_title(m.title).title.should == m.title
  end
end

describe MoviesController, "edit method" do
  it "should find the movie to edit by id" do
    m = FactoryGirl.create(:movie)
    get :edit, :id => m.id
    assigns(:movie).id.should == m.id
  end
end

describe MoviesController, "update method" do
  it "should find the movie to update by id" do
    m = FactoryGirl.create(:movie)
    m.rating = "PG"
    put :update, :id => m.id, :ratings => {"G" => 1} 

    get :show, :id => m.id
    assigns(:movie).rating.should_not == m.rating
  end
end