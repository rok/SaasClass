class Movie < ActiveRecord::Base
  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end
  
  def self.similar_movies(id)
    director = Movie.find_by_id(id).director
    return Movie.find_all_by_director(director)
  end
  
  def similar_movies_path(id,director)
	  if Movie.find_all_by_director(director) == Movie.find_all_by_director(nil) || Movie.find_all_by_director(director) == Movie.find_all_by_director("")
      "/movies/?similar=" << id.to_s
	  else
      return "/movies/" << id.to_s << "/similar"
	  end
  end
end
